
const DeptDetail = () => {
  return (
    <div>DeptDetail</div>
  )
}

export default DeptDetail