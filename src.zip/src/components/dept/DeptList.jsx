import { useEffect, useState } from "react"
import { deptListDB } from "../../service/deptService"

const DeptList = () => {
  const [depts, setDepts] = useState([])
  const deptList = async () => {

  }
  useEffect(() => {
    deptListDB()
    const dept = {
      dept: 0,
      dname: '',
      loc: ''
    }
  },[])
  const res = await deptListDB(dept)
  setDepts(res.data)
  // or setDepts(res)?
  return (
    <div>DeptList</div>
  )
}

export default DeptList