import Footer from "../include/Footer"
import Header from "../include/Header"

const NewsPage = () => {
  return (
    <>
      <Header />
      NewsPage
      <Footer />
    </>
  )
}

export default NewsPage